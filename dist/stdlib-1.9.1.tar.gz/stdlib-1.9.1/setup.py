from setuptools import setup

setup(name="stdlib",
      version="1.9.1",
      description="A worse module ever made..",
      author="UwU",
      packages=["stdlib"],
      zip_safe=False)
