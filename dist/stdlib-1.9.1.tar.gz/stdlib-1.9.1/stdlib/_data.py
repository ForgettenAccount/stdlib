# This is for data only
_unsorted = ("__author__", "__version__", "println", "add", "subtract", "multiply", "divide", "version", "opendir",
             "termexec", "python3", "time", "date", "newln", "recursionlimit","getrecurlimit", "error",
             "reverse", "palindrome", "FatalModuleError", "makedir", "removedir", "delay",
             "stdlibhelp", "libhelp", "scanln", "rand", "color")

_sorted = sorted(_unsorted, key=None)

_data = _sorted
